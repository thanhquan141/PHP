import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class form extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField txtMaNS, txtHoDem, txtTen, txtBangCap;

    public form() {
        setTitle("Quản lý nhân sự");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Tạo bảng và mô hình
        model = new DefaultTableModel();
        model.addColumn("Mã nhân sự");
        model.addColumn("Họ đệm");
        model.addColumn("Tên");
        model.addColumn("Bằng cấp");
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Thêm các trường nhập liệu và nút chức năng
        JPanel panelInput = new JPanel(new GridLayout(4, 2));
        panelInput.add(new JLabel("Mã nhân sự:"));
        txtMaNS = new JTextField();
        panelInput.add(txtMaNS);
        panelInput.add(new JLabel("Họ đệm:"));
        txtHoDem = new JTextField();
        panelInput.add(txtHoDem);
        panelInput.add(new JLabel("Tên:"));
        txtTen = new JTextField();
        panelInput.add(txtTen);
        panelInput.add(new JLabel("Bằng cấp:"));
        txtBangCap = new JTextField();
        panelInput.add(txtBangCap);

        JPanel panelButtons = new JPanel(new FlowLayout());
        JButton btnThem = new JButton("Thêm");
        btnThem.addActionListener(e -> themNhansu());
        panelButtons.add(btnThem);

        JButton btnLoadAPI = new JButton("Load API");
        btnLoadAPI.addActionListener(e -> loadDanhSachNhansu());
        panelButtons.add(btnLoadAPI);

        // Thêm các thành phần vào giao diện
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelInput, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(panelButtons, BorderLayout.SOUTH);

        // Load danh sách nhân sự khi mở form
        loadDanhSachNhansu();
    }

    private void themNhansu() {
        // Lấy dữ liệu từ các trường nhập liệu
        String maNS = txtMaNS.getText();
        String hoDem = txtHoDem.getText();
        String ten = txtTen.getText();
        String bangCap = txtBangCap.getText();

        try {
            // Đường dẫn của API themnhansu.php
            String apiUrl = "http://localhost/1_Project_PHP_TaoAPI/themnhansu.php?manhansu=" + maNS +
                    "&hodem=" + hoDem + "&ten=" + ten + "&bangcap=" + bangCap;

            // Gửi yêu cầu GET đến API để thêm nhân sự
            @SuppressWarnings("deprecation")
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Kiểm tra phản hồi từ API
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Nếu thêm thành công, load lại danh sách nhân sự
                loadDanhSachNhansu();
            } else {
                // Nếu thất bại, thông báo lỗi
                JOptionPane.showMessageDialog(this, "Thêm nhân sự không thành công!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadDanhSachNhansu() {
        try {
            // Đường dẫn của API xemnhansu.php
            String apiUrl = "http://localhost/1_Project_PHP_TaoAPI/xemnhansu.php";

            // Gửi yêu cầu GET đến API và nhận phản hồi
            @SuppressWarnings("deprecation")
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Đọc dữ liệu từ API
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Phân tích dữ liệu từ API và hiển thị trên bảng
            model.setRowCount(0);
            String[] lines = response.toString().split("\n");
            for (String line : lines) {
                String[] rowData = line.split(",");
                model.addRow(rowData);
            }
            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            form form = new form();
            form.setVisible(true);
        });
    }
}
