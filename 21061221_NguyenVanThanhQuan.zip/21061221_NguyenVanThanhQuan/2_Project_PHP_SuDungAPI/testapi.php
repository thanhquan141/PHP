<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test API</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Xuất danh sách nhân sự</h2>
    <?php
    $url = "http://localhost/21061221_NguyenVanThanhQuan/1_Project_PHP_TaoAPI/xemnhansu.php";
    $data = file_get_contents($url);
    $nhansu = json_decode($data, true);

    if (!empty($nhansu)) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Mã nhân sự</th><th>Họ đệm</th><th>Tên</th><th>Bằng cấp</th></tr>";
        foreach ($nhansu as $ns) {
            echo "<tr>";
            echo "<td>".$ns['id']."</td>";
            echo "<td>".$ns['manhansu']."</td>";
            echo "<td>".$ns['hodem']."</td>";
            echo "<td>".$ns['ten']."</td>";
            echo "<td>".$ns['bangcap']."</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Không có nhân sự nào";
    }
    ?>

    <h2>Thêm nhân sự</h2>
    <form action="http://localhost/21061221_NguyenVanThanhQuan/1_Project_PHP_TaoAPI/themnhansu.php" method="post">
        <label for="manhansu">Mã nhân sự:</label>
        <input type="text" id="manhansu" name="manhansu" required><br>
        <label for="hodem">Họ đệm:</label>
        <input type="text" id="hodem" name="hodem" required><br>
        <label for="ten">Tên:</label>
        <input type="text" id="ten" name="ten" required><br>
        <label for="bangcap">Bằng cấp:</label>
        <input type="text" id="bangcap" name="bangcap"><br>
        <button type="submit">Thêm nhân sự</button>
    </form>

    <h2>Sửa nhân sự</h2>
    <form action="http://localhost/21061221_NguyenVanThanhQuan/1_Project_PHP_TaoAPI/suanhansu.php" method="post">
        <label for="id">ID nhân sự:</label>
        <input type="text" id="id" name="id" required><br>
        <label for="manhansu">Mã nhân sự:</label>
        <input type="text" id="manhansu" name="manhansu" required><br>
        <label for="hodem">Họ đệm:</label>
        <input type="text" id="hodem" name="hodem" required><br>
        <label for="ten">Tên:</label>
        <input type="text" id="ten" name="ten" required><br>
        <label for="bangcap">Bằng cấp:</label>
        <input type="text" id="bangcap" name="bangcap"><br>
        <button type="submit">Sửa nhân sự</button>
    </form>

    <h2>Xóa nhân sự</h2>
    <form action="http://localhost/21061221_NguyenVanThanhQuan/1_Project_PHP_TaoAPI/xoanhansu.php" method="get">
        <label for="id">ID nhân sự:</label>
        <input type="text" id="id" name="id" required><br>
        <button type="submit">Xóa nhân sự</button>
    </form>
</body>
</html>
