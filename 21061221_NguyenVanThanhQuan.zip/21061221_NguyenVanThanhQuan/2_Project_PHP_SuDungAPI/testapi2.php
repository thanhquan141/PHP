<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách nhân sự</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Danh sách nhân sự</h2>
    <table>
        <thead>
            <tr>
                <th>Mã nhân sự</th>
                <th>Họ đệm</th>
                <th>Tên</th>
                <th>Bằng cấp</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Đường dẫn của API xemnhansu.php
            $apiUrl = "http://localhost/21061221_NguyenVanThanhQuan/1_Project_PHP_TaoAPI/xemnhansu.php";

            // Gửi yêu cầu GET đến API và nhận phản hồi
            $response = file_get_contents($apiUrl);

            // Phân tích dữ liệu JSON
            $data = json_decode($response);

            // Hiển thị dữ liệu trong bảng
            foreach ($data as $row) {
                echo "<tr>";
                echo "<td>{$row->manhansu}</td>";
                echo "<td>{$row->hodem}</td>";
                echo "<td>{$row->ten}</td>";
                echo "<td>{$row->bangcap}</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
