<?php
header("Content-Type: application/json");

// Lấy dữ liệu từ phần body của yêu cầu
$data = json_decode(file_get_contents("php://input"), true);

// Kiểm tra dữ liệu đã được gửi hay chưa
if (!empty($data['manhansu']) && !empty($data['hodem']) && !empty($data['ten'])) {
    // Kết nối đến cơ sở dữ liệu
    $conn = new mysqli("localhost", "usercnmoi", "123456", "dbcnmoi");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Chuẩn bị câu lệnh SQL để thêm nhân sự
    $sql = "INSERT INTO nhansu (manhansu, hodem, ten, bangcap) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $data['manhansu'], $data['hodem'], $data['ten'], $data['bangcap']);

    // Thực thi câu lệnh và kiểm tra kết quả
    if ($stmt->execute() === TRUE) {
        echo json_encode(array("message" => "Thêm nhân sự thành công"));
    } else {
        echo json_encode(array("message" => "Thêm nhân sự thất bại"));
    }

    // Đóng kết nối
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(array("message" => "Dữ liệu không hợp lệ"));
}
?>
