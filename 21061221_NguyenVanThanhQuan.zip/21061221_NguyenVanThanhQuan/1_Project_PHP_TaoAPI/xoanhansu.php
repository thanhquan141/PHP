<?php
header("Content-Type: application/json");

// Lấy id của nhân sự cần xóa
$id = $_GET['id'];

// Kiểm tra id có tồn tại hay không
if (!empty($id)) {
    // Kết nối đến cơ sở dữ liệu
    $conn = new mysqli("localhost", "usercnmoi", "123456", "dbcnmoi");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Chuẩn bị câu lệnh SQL để xóa nhân sự
    $sql = "DELETE FROM nhansu WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    // Thực thi câu lệnh và kiểm tra kết quả
    if ($stmt->execute() === TRUE) {
        echo json_encode(array("message" => "Xóa nhân sự thành công"));
    } else {
        echo json_encode(array("message" => "Xóa nhân sự thất bại"));
    }

    // Đóng kết nối
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(array("message" => "ID không được trống"));
}
?>
