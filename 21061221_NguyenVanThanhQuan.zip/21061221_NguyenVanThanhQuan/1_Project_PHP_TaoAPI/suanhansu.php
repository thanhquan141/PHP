<?php
header("Content-Type: application/json");

// Lấy dữ liệu từ phần body của yêu cầu
$data = json_decode(file_get_contents("php://input"), true);

// Kiểm tra dữ liệu đã được gửi hay chưa
if (!empty($data['id']) && !empty($data['manhansu']) && !empty($data['hodem']) && !empty($data['ten'])) {
    // Kết nối đến cơ sở dữ liệu
    $conn = new mysqli("localhost", "usercnmoi", "123456", "dbcnmoi");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Chuẩn bị câu lệnh SQL để cập nhật nhân sự
    $sql = "UPDATE nhansu SET manhansu = ?, hodem = ?, ten = ?, bangcap = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $data['manhansu'], $data['hodem'], $data['ten'], $data['bangcap'], $data['id']);

    // Thực thi câu lệnh và kiểm tra kết quả
    if ($stmt->execute() === TRUE) {
        echo json_encode(array("message" => "Cập nhật nhân sự thành công"));
    } else {
        echo json_encode(array("message" => "Cập nhật nhân sự thất bại"));
    }

    // Đóng kết nối
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(array("message" => "Dữ liệu không hợp lệ"));
}
?>
