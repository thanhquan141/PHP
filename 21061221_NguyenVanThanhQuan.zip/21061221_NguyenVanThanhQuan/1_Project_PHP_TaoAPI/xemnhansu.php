<?php
// Kết nối đến MySQL Server
$conn = new mysqli("localhost", "usercnmoi", "123456", "dbcnmoi");

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Thiết lập header trả về dạng JSON
header("Content-Type: application/json");

// Truy vấn SQL để lấy danh sách nhân sự
$sql = "SELECT * FROM nhansu";
$result = $conn->query($sql);

// Kiểm tra và trả về kết quả
if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode(array("message" => "Không có nhân sự nào"));
}

// Đóng kết nối
$conn->close();
?>
