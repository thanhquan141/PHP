-- Tạo cơ sở dữ liệu dbcnmoi
CREATE DATABASE IF NOT EXISTS dbcnmoi;

-- Sử dụng cơ sở dữ liệu dbcnmoi
USE dbcnmoi;

-- Tạo bảng nhansu
CREATE TABLE IF NOT EXISTS nhansu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    manhansu VARCHAR(20) NOT NULL,
    hodem VARCHAR(50) NOT NULL,
    ten VARCHAR(50) NOT NULL,
    bangcap VARCHAR(50)
);

-- Nhập dữ liệu mẫu vào bảng nhansu
INSERT INTO nhansu (manhansu, hodem, ten, bangcap) VALUES
('MS001', 'Nguyễn', 'Văn A', 'Cử nhân Kinh tế'),
('MS002', 'Trần', 'Thị B', 'Cử nhân Luật'),
('MS003', 'Nguyễn', 'Văn Thành Quân', 'Kỷ Sư CNTT'),
('MS004', 'Lê', 'Hồng C', 'Thạc sĩ Quản trị kinh doanh');
